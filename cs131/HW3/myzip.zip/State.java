interface State {
    int getMaxval();
    byte[] getArr();
    boolean swap(int i, int j);
}