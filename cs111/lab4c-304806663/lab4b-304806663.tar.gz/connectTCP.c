#include <arpa/inet.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>

//NAME: Jennie Zheng
//EMAIL: jenniezheng321@gmail.com
//ID: 304806663



//connects to tcp
void connectMe(int PORT, int SOCKETFD, char* HOST, int ID){
	struct sockaddr_in  serv_addr;
	struct hostent *server;

	SOCKETFD = socket(AF_INET, SOCK_STREAM, 0);
	if (SOCKETFD < 0) {
	fprintf(stderr,"Error: Failed to open socket\n");
	exit(1);
	}

	server = gethostbyname(HOST);
	if (server == NULL) {
	fprintf(stderr,"Error: Failed to find host\n");
	exit(0);
	}

	memset((char *)&serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	memcpy((char *)&serv_addr.sin_addr.s_addr, (char *)server->h_addr, server->h_length);
	serv_addr.sin_port = htons(PORT);
	serv_addr.sin_addr.s_addr = inet_addr(HOST);

	/* connect to server */
	if (connect(SOCKETFD, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0) {
		fprintf(stderr,"Error: Failed to connect\n");
		exit(1);
	}

}