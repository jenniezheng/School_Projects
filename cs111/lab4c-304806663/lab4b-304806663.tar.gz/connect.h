void connectMe(int PORT, int SOCKETFD, char* HOST);
